#include "mystring.h"

int mystrlen(char *str)
{
  int length;
  length=strlen(str);
  return length;
}