#include "bitmask.h"

int flip(int num)
{
    int flippedNumber;
    flippedNumber = ~num;
    return flippedNumber;
}