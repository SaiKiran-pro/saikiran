#include "mystring.h"
char *mystrcpy(char *string1, char* string)
{
  return strcpy(string1,string);
}