#include "mystring.h"
char *mystrcat(char *str1, const char *str2)
{
    strcat(str1, str2);
}