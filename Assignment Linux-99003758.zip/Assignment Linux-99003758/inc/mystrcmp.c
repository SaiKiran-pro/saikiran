#include "mystring.h"

int mystrcmp(const char* str1, const char* str2)
{
    return strcmp(str1, str2);
}