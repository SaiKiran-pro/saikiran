#ifndef __MYUTIL_H


#include<stdio.h>
#include<stdlib.h>
#include <stdarg.h> 

void Prime_1(int num);
int factorial(unsigned int n);
int isPalindrome(int number);
int min(int arg_count, ...);


#endif