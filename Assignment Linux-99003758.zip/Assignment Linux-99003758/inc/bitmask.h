#ifndef __BITMASK_H
#define __BITMASK_H

#include<stdio.h>
#include<stdlib.h>

int flip(int num);
int setBit(int m, int o);
int resetBit(int m, int o);

#endif